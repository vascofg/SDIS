package interfaces;

import message.Message;

public interface SendClipboardMessage {
	public void sendClipboardMessage(Message msg);
}
